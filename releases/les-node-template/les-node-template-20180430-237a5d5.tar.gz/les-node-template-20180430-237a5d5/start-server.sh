#!/bin/sh
echo Starting server.
sleep 5
node dist/app les
