export default class NoOpLogger {
  info() {
    // nothing to do here
  }

  debug() {
    // nothing to do here
  }

  error() {
    // nothing to do here
  }
}
