export default async function bootstrap() {
  //Nothing to do
}